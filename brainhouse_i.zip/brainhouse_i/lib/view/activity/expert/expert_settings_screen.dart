import 'package:brainhouse_i/view/activity/expert/app_theme.dart';
import 'package:flutter/material.dart';
class ExpertSettings extends StatefulWidget {
  @override
  _ExpertSettingsState createState() => _ExpertSettingsState();
}

class _ExpertSettingsState extends State<ExpertSettings> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("Settings"),),
    );
  }
}
