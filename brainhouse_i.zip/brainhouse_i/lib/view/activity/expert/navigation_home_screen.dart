import 'package:brainhouse_i/view/activity/expert/app_theme.dart';
import 'package:brainhouse_i/view/activity/expert/expert_dashboard_screen.dart';
import 'package:brainhouse_i/view/activity/expert/expert_my_profile_nav.dart';
import 'package:brainhouse_i/view/activity/expert/expert_profile.dart';
import 'package:brainhouse_i/view/activity/expert/expert_Invoices_screen.dart';
import 'package:brainhouse_i/view/activity/expert/expert_settings_screen.dart';
import 'package:brainhouse_i/view/activity/expert/expert_ticket.dart';
import 'package:brainhouse_i/view/activity/expert/expert_home_screen.dart';
import 'package:brainhouse_i/view/activity/expert/expert_notification_screen.dart';
import 'package:brainhouse_i/view/activity/expert/expert_ticket_tab_bar.dart';
import 'package:brainhouse_i/view/custom_widget/drawer_user_controller.dart';
import 'package:brainhouse_i/view/custom_widget/home_drawer.dart';
import 'package:flutter/material.dart';

class NavigationHomeScreen extends StatefulWidget {
  @override
  _NavigationHomeScreenState createState() => _NavigationHomeScreenState();
}

class _NavigationHomeScreenState extends State<NavigationHomeScreen> {
  Widget screenView;
  DrawerIndex drawerIndex;
  AnimationController sliderAnimationController;

  @override
  void initState() {
    drawerIndex = DrawerIndex.HOME;
    screenView = const ExpertHome();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.nearlyWhite,
      child: SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
          backgroundColor: AppTheme.nearlyWhite,
          body: DrawerUserController(
            screenIndex: drawerIndex,
            drawerWidth: MediaQuery.of(context).size.width * 0.75,
            animationController: (AnimationController animationController) {
              sliderAnimationController = animationController;
            },
            onDrawerCall: (DrawerIndex drawerIndexdata) {
              changeIndex(drawerIndexdata);
            },
            screenView: screenView,
          ),
        ),
      ),
    );
  }

  void changeIndex(DrawerIndex drawerIndexdata) {
    if (drawerIndex != drawerIndexdata) {
      drawerIndex = drawerIndexdata;
      if (drawerIndex == DrawerIndex.HOME) {
        setState(() {
          screenView = const ExpertHome();
//          Navigator.push(
//            context,
//            MaterialPageRoute(builder: (context) => ExpertDashboard()),
//          );
        });
      }
      else if (drawerIndex == DrawerIndex.PROFILE) {
        setState(() {
          screenView = ExpertMyProfile();
//          Navigator.push(
//            context,
//            MaterialPageRoute(builder: (context) => ExpertProfile()),
//          );
        });
      } else if (drawerIndex == DrawerIndex.MY_TICKET) {
        setState(() {
          screenView = Ticket_Tab_bar();
//          Navigator.push(
//            context,
//            MaterialPageRoute(builder: (context) => Ticket_Tab_bar()),
//          );
        });
      } else if (drawerIndex == DrawerIndex.INVOICES) {
        setState(() {
          screenView = ExpertInvoice();
//          Navigator.push(
//            context,
//            MaterialPageRoute(builder: (context) => ExpertInvoice()),
//          );
         // screenView = ExpertInvoice();
        });
      } else if (drawerIndex == DrawerIndex.NOTIFICATIONS) {
        setState(() {
          screenView = ExpertNotification();
//          Navigator.push(
//            context,
//            MaterialPageRoute(builder: (context) => ExpertNotification()),
//          );
        });
      } else if (drawerIndex == DrawerIndex.SETTINGS) {
        setState(() {
          screenView = ExpertNotification();
//          Navigator.push(
//            context,
//            MaterialPageRoute(builder: (context) => ExpertSettings()),
//          );
        });
      }
    }
  }
}
