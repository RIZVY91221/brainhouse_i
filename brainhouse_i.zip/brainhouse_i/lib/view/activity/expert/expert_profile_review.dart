import 'package:flutter/material.dart';
class ReviewProfile extends StatefulWidget {
  @override
  _ReviewProfileState createState() => _ReviewProfileState();
}

class _ReviewProfileState extends State<ReviewProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child:Text("Review")
      ),
    );
  }
}
